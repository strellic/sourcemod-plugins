Add a new entry to databases.cfg with the title "SkillBot" to store players' points.

SQLite Option:
"SkillBot"
{
	"driver"			"sqlite"
	"database"			"skillbot-local"
}